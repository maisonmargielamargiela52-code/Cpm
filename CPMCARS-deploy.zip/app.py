import os
import sqlite3
import secrets
from pathlib import Path
from functools import wraps

from flask import (
    Flask, render_template, request, redirect,
    url_for, session, flash, abort
)
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = os.environ.get("CPMCARS_SECRET") or secrets.token_hex(32)

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "cpmcars.db"
UPLOAD_DIR = BASE_DIR / "static" / "uploads"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

ALLOWED_EXTENSIONS = {"png", "jpg", "jpeg", "webp"}
MAX_CONTENT_LENGTH = 8 * 1024 * 1024
app.config["MAX_CONTENT_LENGTH"] = MAX_CONTENT_LENGTH


def connect_db():
    db = sqlite3.connect(DB_PATH)
    db.row_factory = sqlite3.Row
    return db


def init_db():
    with connect_db() as db:
        db.executescript("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                whatsapp TEXT,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'approved',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );

            CREATE TABLE IF NOT EXISTS applications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL UNIQUE,
                voucher_reference TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );

            CREATE TABLE IF NOT EXISTS cars (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                seller_id INTEGER NOT NULL,
                title TEXT NOT NULL,
                description TEXT NOT NULL,
                price REAL NOT NULL,
                image TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'available',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY(seller_id) REFERENCES users(id)
            );
            CREATE TABLE IF NOT EXISTS car_images (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                car_id INTEGER NOT NULL,
                image TEXT NOT NULL,
                FOREIGN KEY(car_id) REFERENCES cars(id)
            );

            CREATE TABLE IF NOT EXISTS seller_memberships (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                plan TEXT NOT NULL CHECK(plan IN ('monthly', 'lifetime')),
                voucher_reference TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                approved_at TIMESTAMP,
                expires_at TIMESTAMP,
                FOREIGN KEY(user_id) REFERENCES users(id)
            );
        """)

        # Preserve existing primary images in the new image table.
        existing = db.execute(
            "SELECT id, image FROM cars"
        ).fetchall()

        for car in existing:
            if car["image"]:
                found = db.execute(
                    "SELECT id FROM car_images WHERE car_id = ? AND image = ?",
                    (car["id"], car["image"])
                ).fetchone()
                if not found:
                    db.execute(
                        "INSERT INTO car_images (car_id, image) VALUES (?, ?)",
                        (car["id"], car["image"])
                    )


init_db()


def current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None

    with connect_db() as db:
        return db.execute(
            "SELECT * FROM users WHERE id = ?", (user_id,)
        ).fetchone()


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user():
            flash("Please log in first.")
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper


def active_membership(user_id):
    with connect_db() as db:
        return db.execute("""
            SELECT *
            FROM seller_memberships
            WHERE user_id = ?
              AND status = 'approved'
              AND (
                    plan = 'lifetime'
                    OR (
                        plan = 'monthly'
                        AND expires_at IS NOT NULL
                        AND expires_at > CURRENT_TIMESTAMP
                    )
              )
            ORDER BY
                CASE WHEN plan = 'lifetime' THEN 0 ELSE 1 END,
                id DESC
            LIMIT 1
        """, (user_id,)).fetchone()


def pending_membership(user_id):
    with connect_db() as db:
        return db.execute("""
            SELECT *
            FROM seller_memberships
            WHERE user_id = ? AND status = 'pending'
            ORDER BY id DESC LIMIT 1
        """, (user_id,)).fetchone()


def seller_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        user = current_user()

        if not user:
            flash("Please log in first.")
            return redirect(url_for("login"))

        if user["role"] != "seller":
            abort(403)

        if user["status"] != "approved":
            flash("Your seller account is awaiting approval.")
            return redirect(url_for("dashboard"))

        if not active_membership(user["id"]):
            flash("Choose an active seller membership to continue.")
            return redirect(url_for("seller_membership"))

        return fn(*args, **kwargs)
    return wrapper


def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get("is_admin"):
            return redirect(url_for("admin_login"))
        return fn(*args, **kwargs)
    return wrapper


def page(title, content, **context):
    return render_template(
        "page.html",
        title=title,
        content=content,
        user=current_user(),
        **context
    )


@app.route("/")
def home():
    return render_template("index.html")


@app.route("/buy")
def buy():
    return render_template("buyer.html")


@app.route("/sell")
def sell():
    return render_template("seller.html")


@app.route("/register/buyer", methods=["GET", "POST"])
def register_buyer():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        if not name or not email or len(password) < 8:
            flash("Enter your name and email, and use a password of at least 8 characters.")
            return redirect(url_for("register_buyer"))

        try:
            with connect_db() as db:
                db.execute("""
                    INSERT INTO users
                    (name, email, password_hash, role, status)
                    VALUES (?, ?, ?, 'buyer', 'approved')
                """, (name, email, generate_password_hash(password)))
            flash("Buyer account created. You can now log in.")
            return redirect(url_for("login"))
        except sqlite3.IntegrityError:
            flash("That email is already registered.")

    content = """
    <h1>Create your buyer account</h1>
    <p>Register to explore CPM car listings.</p>
    <form method="post">
      <label>Full name</label>
      <input name="name" required maxlength="80">
      <label>Email address</label>
      <input type="email" name="email" required maxlength="160">
      <label>Password (at least 8 characters)</label>
      <input type="password" name="password" required minlength="8">
      <button>Create account</button>
    </form>
    <p>Already registered? <a href="/login">Log in</a></p>
    """
    return page("Buyer registration", content)


@app.route("/register/seller", methods=["GET", "POST"])
def register_seller():
    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        whatsapp = request.form.get("whatsapp", "").strip()
        password = request.form.get("password", "")
        reference = request.form.get("voucher_reference", "").strip()
        plan = request.form.get("plan", "").strip()

        if (
            not all([name, email, whatsapp, reference])
            or plan not in ("monthly", "lifetime")
            or len(password) < 8
        ):
            flash("Complete every field and use a password of at least 8 characters.")
            return redirect(url_for("register_seller"))

        try:
            with connect_db() as db:
                cur = db.execute("""
                    INSERT INTO users
                    (name, email, whatsapp, password_hash, role, status)
                    VALUES (?, ?, ?, ?, 'seller', 'pending')
                """, (
                    name, email, whatsapp,
                    generate_password_hash(password)
                ))

                db.execute("""
                    INSERT INTO applications
                    (user_id, voucher_reference, status)
                    VALUES (?, ?, 'pending')
                """, (cur.lastrowid, reference))

                db.execute("""
                    INSERT INTO seller_memberships
                    (user_id, plan, voucher_reference, status)
                    VALUES (?, ?, ?, 'pending')
                """, (cur.lastrowid, plan, reference))

            flash("Seller application and membership submitted for manual review.")
            return redirect(url_for("login"))

        except sqlite3.IntegrityError:
            flash("That email is already registered.")

    content = """
    <h1>Apply to become a seller</h1>
    <p>Your seller account will remain locked until the administrator reviews your application.</p>
    <form method="post">
      <label>Full name</label>
      <input name="name" required maxlength="80">
      <label>Email address</label>
      <input type="email" name="email" required maxlength="160">
      <label>WhatsApp number</label>
      <input name="whatsapp" type="tel" required maxlength="30"
             placeholder="Include your country code">
      <label>Password (at least 8 characters)</label>
      <input name="password" type="password" required minlength="8">
      <label>Choose seller membership</label>
      <select name="plan" required>
        <option value="monthly">Monthly Seller — R5 for 30 days</option>
        <option value="lifetime">Lifetime Seller — R25 once</option>
      </select>
      <label>Payment receipt/reference</label>
      <input name="voucher_reference" required maxlength="120"
             placeholder="Payment reference, not voucher PIN">
      <p class="hint">Do not enter a redeemable voucher PIN or password here. Submit a receipt/reference you can show the administrator for manual review.</p>
      <button>Submit seller application</button>
    </form>
    <p>Already registered? <a href="/login">Log in</a></p>
    """
    return page("Seller registration", content)


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        with connect_db() as db:
            user = db.execute(
                "SELECT * FROM users WHERE email = ?", (email,)
            ).fetchone()

        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            flash("Welcome back!")
            return redirect(url_for("dashboard"))

        flash("Email or password is incorrect.")

    content = """
    <h1>Log in</h1>
    <form method="post">
      <label>Email address</label>
      <input type="email" name="email" required>
      <label>Password</label>
      <input type="password" name="password" required>
      <button>Log in</button>
    </form>
    <p>New buyer? <a href="/register/buyer">Create buyer account</a></p>
    <p>Want to sell? <a href="/register/seller">Apply as a seller</a></p>
    """
    return page("Log in", content)


@app.route("/logout")
def logout():
    session.clear()
    flash("You have been logged out.")
    return redirect(url_for("home"))


@app.route("/dashboard")
@login_required
def dashboard():
    user = current_user()

    if user["role"] == "seller" and user["status"] != "approved":
        return page(
            "Application pending",
            "<h1>Seller application pending</h1>"
            "<p>Your account cannot publish listings until an administrator approves it.</p>"
            '<p><a href="/settings">Account settings</a></p>'
        )

    listings = []
    if user["role"] == "seller":
        with connect_db() as db:
            rows = db.execute(
                "SELECT * FROM cars WHERE seller_id = ? ORDER BY id DESC",
                (user["id"],)
            ).fetchall()

            for row in rows:
                car = dict(row)
                photos = db.execute(
                    "SELECT image FROM car_images WHERE car_id = ? ORDER BY id",
                    (car["id"],)
                ).fetchall()
                car["photos"] = [x["image"] for x in photos]
                if not car["photos"] and car["image"]:
                    car["photos"] = [car["image"]]
                listings.append(car)

        membership = active_membership(user["id"])
        waiting_membership = pending_membership(user["id"])

        with connect_db() as db:
            expired_membership = db.execute("""
                SELECT * FROM seller_memberships
                WHERE user_id = ?
                  AND plan = 'monthly'
                  AND status = 'approved'
                  AND expires_at IS NOT NULL
                  AND expires_at <= CURRENT_TIMESTAMP
                ORDER BY id DESC
                LIMIT 1
            """, (user["id"],)).fetchone()

        return render_template(
            "dashboard.html",
            user=user,
            cars=listings,
            membership=membership,
            waiting_membership=waiting_membership,
            expired_membership=expired_membership
        )

    return render_template("dashboard.html", user=user, cars=[])


@app.route("/cars")
def cars():
    with connect_db() as db:
        rows = db.execute("""
            SELECT cars.*, users.name AS seller_name, users.whatsapp
            FROM cars
            JOIN users ON users.id = cars.seller_id
            WHERE cars.status = 'available' AND users.status = 'approved'
            ORDER BY cars.id DESC
        """).fetchall()

        listings = []
        for row in rows:
            car = dict(row)
            photos = db.execute(
                "SELECT image FROM car_images WHERE car_id = ? ORDER BY id",
                (car["id"],)
            ).fetchall()
            car["photos"] = [x["image"] for x in photos]
            if not car["photos"] and car["image"]:
                car["photos"] = [car["image"]]
            listings.append(car)

    return render_template("cars.html", cars=listings, user=current_user())


def allowed_image(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


@app.route("/seller/membership", methods=["GET", "POST"])
@login_required
def seller_membership():
    user = current_user()

    if user["role"] != "seller":
        abort(403)

    if user["status"] != "approved":
        flash("Your seller account must be approved first.")
        return redirect(url_for("dashboard"))

    if request.method == "POST":
        plan = request.form.get("plan", "").strip()
        reference = request.form.get("voucher_reference", "").strip()

        if plan not in ("monthly", "lifetime") or not reference:
            flash("Choose a plan and enter your payment reference.")
            return redirect(url_for("seller_membership"))

        with connect_db() as db:
            pending = db.execute("""
                SELECT id FROM seller_memberships
                WHERE user_id = ? AND status = 'pending'
                LIMIT 1
            """, (user["id"],)).fetchone()

            if pending:
                flash("You already have a membership payment awaiting review.")
                return redirect(url_for("seller_membership"))

            db.execute("""
                INSERT INTO seller_memberships
                (user_id, plan, voucher_reference, status)
                VALUES (?, ?, ?, 'pending')
            """, (user["id"], plan, reference))

        flash("Membership submitted. Access starts after admin approval.")
        return redirect(url_for("seller_membership"))

    active = active_membership(user["id"])
    pending = pending_membership(user["id"])

    with connect_db() as db:
        expired_membership = db.execute("""
            SELECT * FROM seller_memberships
            WHERE user_id = ?
              AND plan = 'monthly'
              AND status = 'approved'
              AND expires_at IS NOT NULL
              AND expires_at <= CURRENT_TIMESTAMP
            ORDER BY id DESC
            LIMIT 1
        """, (user["id"],)).fetchone()

    content = """
    <h1>Seller membership</h1>
    <p>Buyers can browse CPM CARS for free. Sellers need an active membership to publish cars or mark listings as sold.</p>
    <div style="border:1px solid #343a30;padding:18px;border-radius:14px;margin:18px 0">
      <h2>Monthly Seller — R5</h2>
      <p>30 days of seller access. Renew by submitting another payment reference.</p>
    </div>
    <div style="border:1px solid #343a30;padding:18px;border-radius:14px;margin:18px 0">
      <h2>Lifetime Seller — R25</h2>
      <p>One payment for seller access with no expiry.</p>
    </div>
    {% if active %}
      <p><strong>Active membership:</strong> {{ active.plan|title }}</p>
      {% if active.expires_at %}
        <p><strong>Expires:</strong> {{ active.expires_at }}</p>
      {% else %}
        <p><strong>Expiry:</strong> Never</p>
      {% endif %}
    {% endif %}
    {% if pending %}
      <p style="color:#b8ff35">Your {{ pending.plan }} membership payment is awaiting admin review.</p>
    {% else %}
      <form method="post">
        <label>Choose a plan</label>
        <select name="plan" required>
          <option value="monthly">Monthly — R5 / 30 days</option>
          <option value="lifetime">Lifetime — R25 once</option>
        </select>
        <label>Payment receipt/reference</label>
        <input name="voucher_reference" required maxlength="120"
               placeholder="Reference number, not voucher PIN">
        <p>Do not submit a voucher PIN or password. Your payment reference will be checked manually.</p>
        <button type="submit">Submit membership</button>
      </form>
    {% endif %}
    <p><a href="/dashboard">Back to dashboard</a></p>
    """
    return render_template("membership.html", user=user, active=active, pending=pending, expired_membership=expired_membership)


@app.route("/sell-car", methods=["GET", "POST"])
@seller_required
def sell_car():
    user = current_user()

    if request.method == "POST":
        title = request.form.get("title", "").strip()
        description = request.form.get("description", "").strip()
        price_text = request.form.get("price", "").strip()
        photos = [
            photo for photo in request.files.getlist("images")
            if photo and photo.filename
        ]

        try:
            price = float(price_text)
            if price <= 0 or price > 100000000:
                raise ValueError
        except ValueError:
            flash("Enter a valid price greater than zero.")
            return redirect(url_for("sell_car"))

        if not title or not description or not photos:
            flash("Enter the car name, price, description, and at least one picture.")
            return redirect(url_for("sell_car"))

        if len(photos) > 6:
            flash("Upload a maximum of 6 pictures per car.")
            return redirect(url_for("sell_car"))

        if any(not allowed_image(photo.filename) for photo in photos):
            flash("Every picture must be JPG, JPEG, PNG or WEBP.")
            return redirect(url_for("sell_car"))

        saved = []
        try:
            for photo in photos:
                safe_name = secure_filename(photo.filename)
                filename = f"{user['id']}_{secrets.token_hex(8)}_{safe_name}"
                photo.save(UPLOAD_DIR / filename)
                saved.append(filename)

            with connect_db() as db:
                cur = db.execute("""
                    INSERT INTO cars
                    (seller_id, title, description, price, image, status)
                    VALUES (?, ?, ?, ?, ?, 'available')
                """, (user["id"], title, description, price, saved[0]))
                car_id = cur.lastrowid

                db.executemany(
                    "INSERT INTO car_images (car_id, image) VALUES (?, ?)",
                    [(car_id, filename) for filename in saved]
                )

        except Exception:
            for filename in saved:
                try:
                    (UPLOAD_DIR / filename).unlink(missing_ok=True)
                except OSError:
                    pass
            raise

        flash("Your car listing and pictures have been published.")
        return redirect(url_for("dashboard"))

    content = """
    <h1>Add your CPM car</h1>
    <p>Upload up to 6 screenshots of the same car.</p>
    <form method="post" enctype="multipart/form-data">
      <label>Car name</label>
      <input name="title" required maxlength="100"
             placeholder="e.g. BMW M4 Liberty Walk">
      <label>Price (R)</label>
      <input name="price" type="number" min="1" step="0.01" required
             placeholder="Enter your price">
      <label>Car pictures (up to 6)</label>
      <input type="file" name="images" accept=".jpg,.jpeg,.png,.webp"
             multiple required>
      <label>Description</label>
      <textarea name="description" required maxlength="1500" rows="5"
        placeholder="Describe the car and modifications."></textarea>
      <button>Publish car listing</button>
    </form>
    """
    return page("Add a car", content)


@app.route("/mark-sold/<int:car_id>", methods=["POST"])
@seller_required
def mark_sold(car_id):
    user = current_user()

    with connect_db() as db:
        db.execute("""
            UPDATE cars SET status = 'sold'
            WHERE id = ? AND seller_id = ?
        """, (car_id, user["id"]))

    flash("Listing marked as sold.")
    return redirect(url_for("dashboard"))




@app.route("/remove-car/<int:car_id>", methods=["POST"])
@seller_required
def remove_car(car_id):
    user = current_user()
    filenames = set()

    with connect_db() as db:
        car = db.execute(
            "SELECT id, image FROM cars WHERE id = ? AND seller_id = ?",
            (car_id, user["id"])
        ).fetchone()

        if not car:
            flash("Car listing not found or you do not have permission to remove it.")
            return redirect(url_for("dashboard"))

        if car["image"]:
            filenames.add(car["image"])

        photos = db.execute(
            "SELECT image FROM car_images WHERE car_id = ?",
            (car_id,)
        ).fetchall()

        for photo in photos:
            if photo["image"]:
                filenames.add(photo["image"])

        db.execute(
            "DELETE FROM car_images WHERE car_id = ?",
            (car_id,)
        )

        db.execute(
            "DELETE FROM cars WHERE id = ? AND seller_id = ?",
            (car_id, user["id"])
        )

    # Delete uploaded files after the database changes succeed.
    for filename in filenames:
        if Path(filename).name != filename:
            continue

        try:
            (UPLOAD_DIR / filename).unlink(missing_ok=True)
        except OSError:
            app.logger.warning("Could not remove car photo: %s", filename)

    flash("Car listing removed successfully.")
    return redirect(url_for("dashboard"))


@app.route("/settings", methods=["GET", "POST"])
@login_required
def settings():
    user = current_user()

    if request.method == "POST":
        name = request.form.get("name", "").strip()
        email = request.form.get("email", "").strip().lower()
        whatsapp = request.form.get("whatsapp", "").strip()

        if not name or not email:
            flash("Name and email are required.")
        else:
            try:
                with connect_db() as db:
                    if user["role"] == "seller":
                        db.execute(
                            "UPDATE users SET name=?, email=?, whatsapp=? WHERE id=?",
                            (name, email, whatsapp, user["id"])
                        )
                    else:
                        db.execute(
                            "UPDATE users SET name=?, email=? WHERE id=?",
                            (name, email, user["id"])
                        )
                flash("Account details updated.")
                return redirect(url_for("settings"))
            except sqlite3.IntegrityError:
                flash("That email address is already in use.")

    user = current_user()
    whatsapp_field = ""
    if user["role"] == "seller":
        whatsapp_field = (
            '<label>WhatsApp number</label>'
            '<input name="whatsapp" type="tel" maxlength="30" value="'
            + (user["whatsapp"] or "").replace("&", "&amp;").replace('"', "&quot;").replace("<", "&lt;").replace(">", "&gt;")
            + '" required>'
        )

    safe_name = (user["name"] or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
    safe_email = (user["email"] or "").replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")

    content = """
    <h1>Account settings</h1>
    <p>Update your CPM CARS account information.</p>
    <form method="post">
      <label>Full name</label>
      <input name="name" maxlength="80" required value="NAME_VALUE">
      <label>Email address</label>
      <input type="email" name="email" maxlength="160" required value="EMAIL_VALUE">
      WHATSAPP_FIELD
      <button>Save changes</button>
    </form>
    <hr>
    <h2>Delete account</h2>
    <p>This permanently removes your account and listings. This action cannot be undone.</p>
    <form method="post" action="/delete-account"
          onsubmit="return confirm('Permanently delete your account and all your listings? This cannot be undone.');">
      <label>Enter your password to confirm</label>
      <input type="password" name="password" required>
      <button style="background:#7c2525">Delete my account</button>
    </form>
    <p><a href="/logout">Log out</a></p>
    """
    content = (
        content.replace("NAME_VALUE", safe_name)
        .replace("EMAIL_VALUE", safe_email)
        .replace("WHATSAPP_FIELD", whatsapp_field)
    )
    return page("Account settings", content)


@app.route("/delete-account", methods=["POST"])
@login_required
def delete_account():
    user = current_user()
    password = request.form.get("password", "")

    if not check_password_hash(user["password_hash"], password):
        flash("Incorrect password. Your account was not deleted.")
        return redirect(url_for("settings"))

    with connect_db() as db:
        car_rows = db.execute(
            "SELECT id, image FROM cars WHERE seller_id = ?",
            (user["id"],)
        ).fetchall()

        filenames = set()
        for car in car_rows:
            if car["image"]:
                filenames.add(car["image"])
            extra = db.execute(
                "SELECT image FROM car_images WHERE car_id = ?",
                (car["id"],)
            ).fetchall()
            filenames.update(item["image"] for item in extra if item["image"])

        db.execute(
            "DELETE FROM car_images WHERE car_id IN (SELECT id FROM cars WHERE seller_id = ?)",
            (user["id"],)
        )
        db.execute("DELETE FROM cars WHERE seller_id = ?", (user["id"],))
        db.execute("DELETE FROM applications WHERE user_id = ?", (user["id"],))
        db.execute("DELETE FROM users WHERE id = ?", (user["id"],))

    for filename in filenames:
        try:
            (UPLOAD_DIR / filename).unlink(missing_ok=True)
        except OSError:
            pass

    session.clear()
    flash("Your account and listings have been deleted.")
    return redirect(url_for("home"))


@app.route("/admin/login", methods=["GET", "POST"])
def admin_login():
    if request.method == "POST":
        expected_email = os.environ.get("CPMCARS_ADMIN_EMAIL", "").strip().lower()
        expected_password = os.environ.get("CPMCARS_ADMIN_PASSWORD", "")
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")

        if not expected_email or not expected_password:
            flash("Admin email or password is not configured.")
        elif (
            secrets.compare_digest(email, expected_email)
            and secrets.compare_digest(password, expected_password)
        ):
            session.clear()
            session["is_admin"] = True
            return redirect(url_for("admin_dashboard"))
        else:
            flash("Incorrect admin email or password.")

    content = """
    <h1>Administrator login</h1>
    <p>Sign in to manage CPM CARS.</p>
    <form method="post">
      <label>Admin email</label>
      <input type="email" name="email" placeholder="Your admin email" required>
      <label>Admin password</label>
      <input type="password" name="password" placeholder="Your password" required>
      <button>Open admin dashboard</button>
    </form>
    """
    return page("Admin login", content)


@app.route("/admin")
@admin_required
def admin_dashboard():
    with connect_db() as db:
        applications = db.execute("""
            SELECT
                applications.id AS application_id,
                applications.voucher_reference,
                applications.status AS application_status,
                applications.created_at,
                users.name,
                users.email,
                users.whatsapp,
                users.status AS account_status
            FROM applications
            JOIN users ON users.id = applications.user_id
            WHERE applications.status = 'pending'
            ORDER BY applications.created_at ASC
        """).fetchall()

        memberships = db.execute("""
            SELECT
                seller_memberships.id AS membership_id,
                seller_memberships.plan,
                seller_memberships.voucher_reference,
                seller_memberships.submitted_at,
                users.name,
                users.email,
                users.whatsapp
            FROM seller_memberships
            JOIN users ON users.id = seller_memberships.user_id
            WHERE seller_memberships.status = 'pending'
              AND users.status = 'approved'
            ORDER BY seller_memberships.submitted_at ASC
        """).fetchall()

    return render_template(
        "admin_dashboard.html",
        applications=applications,
        memberships=memberships
    )


@app.route("/admin/application/<int:application_id>", methods=["POST"])
@admin_required
def review_application(application_id):
    decision = request.form.get("decision")

    if decision not in ("approve", "deny"):
        abort(400)

    with connect_db() as db:
        item = db.execute(
            "SELECT user_id FROM applications WHERE id = ? AND status = 'pending'",
            (application_id,)
        ).fetchone()

        if item:
            status = "approved" if decision == "approve" else "denied"
            db.execute(
                "UPDATE applications SET status = ? WHERE id = ?",
                (status, application_id)
            )
            db.execute(
                "UPDATE users SET status = ? WHERE id = ?",
                (status, item["user_id"])
            )

            # Handle the first membership submitted during registration.
            first_membership = db.execute("""
                SELECT id, plan FROM seller_memberships
                WHERE user_id = ? AND status = 'pending'
                ORDER BY id ASC LIMIT 1
            """, (item["user_id"],)).fetchone()

            if first_membership:
                if status == "approved":
                    if first_membership["plan"] == "monthly":
                        expiry = db.execute(
                            "SELECT datetime('now', '+30 days')"
                        ).fetchone()[0]
                    else:
                        expiry = None

                    db.execute("""
                        UPDATE seller_memberships
                        SET status = 'approved',
                            approved_at = CURRENT_TIMESTAMP,
                            expires_at = ?
                        WHERE id = ?
                    """, (expiry, first_membership["id"]))
                else:
                    db.execute("""
                        UPDATE seller_memberships
                        SET status = 'denied'
                        WHERE id = ?
                    """, (first_membership["id"],))

    flash("Application decision saved.")
    return redirect(url_for("admin_dashboard"))


@app.route("/admin/membership/<int:membership_id>", methods=["POST"])
@admin_required
def review_membership(membership_id):
    decision = request.form.get("decision")
    if decision not in ("approve", "deny"):
        abort(400)

    with connect_db() as db:
        item = db.execute("""
            SELECT seller_memberships.id,
                   seller_memberships.user_id,
                   seller_memberships.plan,
                   users.status AS account_status
            FROM seller_memberships
            JOIN users ON users.id = seller_memberships.user_id
            WHERE seller_memberships.id = ?
              AND seller_memberships.status = 'pending'
        """, (membership_id,)).fetchone()

        if item:
            if decision == "approve":
                if item["account_status"] != "approved":
                    flash("Approve the seller account before approving membership.")
                    return redirect(url_for("admin_dashboard"))

                if item["plan"] == "monthly":
                    expiry = db.execute(
                        "SELECT datetime('now', '+30 days')"
                    ).fetchone()[0]
                else:
                    expiry = None

                db.execute("""
                    UPDATE seller_memberships
                    SET status = 'approved',
                        approved_at = CURRENT_TIMESTAMP,
                        expires_at = ?
                    WHERE id = ?
                """, (expiry, membership_id))
                flash("Membership approved.")
            else:
                db.execute("""
                    UPDATE seller_memberships
                    SET status = 'denied'
                    WHERE id = ?
                """, (membership_id,))
                flash("Membership rejected.")
        else:
            flash("That membership was already reviewed or does not exist.")

    return redirect(url_for("admin_dashboard"))


@app.route("/admin/logout")
def admin_logout():
    session.pop("is_admin", None)
    return redirect(url_for("home"))


@app.errorhandler(413)
def too_large(_error):
    return "Image too large. Maximum upload size is 8 MB.", 413


if __name__ == "__main__":
    app.run(host="127.0.0.1", port=5000, debug=False)
